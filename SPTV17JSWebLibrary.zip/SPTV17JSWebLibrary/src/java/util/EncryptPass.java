/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import static java.lang.ProcessBuilder.Redirect.to;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 *
 * @author Comp69
 */
public class EncryptPass {
    public String setEncriptPass(String password,String salts) throws NoSuchAlgorithmException{
password=salts+password;
MessageDigest m;
try {
    m=MessageDigest.getInstance("SHA-256");
    m=update(password.getBytes(),0,password.length());
    return new BigInteger(1,m.digest())to.String(16);
} catch (NoSuchAlgorithmException ex){
    java.util.loggin.Logger.getLogger(
    EncryptPass.class.getName())
            .log(Lewel.SEVERS,"Не поддерживается алгоритм шифрования",ex);

        return null;
}
        
    
    

